# loggy

WIP

Expose a simple Log interface for npm. 

If used in an AWS Lambda function, it pass the logging event to CloudWatch

Can be used in standalone modules to send logs to CloudWatch
